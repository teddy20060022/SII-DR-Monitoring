select*from sys.tcp_endpoints

go

alter endpoint Hadr_endpoint state=started
AS TCP (listener_port= 7022)
FOR database_mirroring (ROLE=ALL)

select serverproperty('IsHADREnabled')

go

select
suser_name(principal_id) as endpoint_owner
,name as endpoint_name
from sys.database_mirroring_endpoints
go

alter authorization on endpoint::Hadr_endpoint TO [CT\s-IDR-P-SP4-0-SQ00]

go

select*from sys.dm_server_services