select DB_NAME() as 'Database','Proc' = SCHEMA_NAME(p.schema_id)+'.'+p.name
    , 'Type' = per.state_desc, 'Permission' = per.permission_name
    , 'Login' = pri.name, 'Type' = pri.type_desc 
    , *
From sys.objects as p
left join sys.database_permissions as per on p.object_id = per.major_id
left join sys.database_principals as pri on per.grantee_principal_id = pri.principal_id
where p.object_id IN (1352248468,1640249494) AND pri.name = 'dsc_chare_link'

go

--select*from sys.objects where name LIKE '%F_check_doa%'

select*from sys.database_principals 