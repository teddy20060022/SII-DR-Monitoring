select
mf.database_id,
sd.name as 'databases',
mf.name as 'file_name',
mf.physical_name
from sys.master_files mf
inner join sys.databases sd ON mf.database_id=sd.database_id