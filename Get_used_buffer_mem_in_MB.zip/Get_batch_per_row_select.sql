--select count(*) from  mars.Dbo.new_AuditRecordField where ID between 1 and 200
--2092140
GO
select*from 
    (select 
         row_number() over (order by id) as row_num, * 
     from 
         mars.Dbo.new_AuditRecordField) as batch
where 
    batch.row_num between 100 and 10000
