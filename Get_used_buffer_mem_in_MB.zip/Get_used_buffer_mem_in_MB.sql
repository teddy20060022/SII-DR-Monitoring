SELECT
SCHEMA_NAME(objects.schema_id) AS SchemaName,
objects.name AS ObjectName,
objects.type_desc AS ObjectType,
COUNT(*) AS [Total Pages In Buffer],
COUNT(*) * 8 / 1024 AS [Buffer Size in MB],
    SUM(CASE dm_os_buffer_descriptors.is_modified 
WHEN 1 THEN 1 ELSE 0
END) AS [Dirty Pages],
    SUM(CASE dm_os_buffer_descriptors.is_modified 
WHEN 1 THEN 0 ELSE 1
END) AS [Clean Pages],
    SUM(CASE dm_os_buffer_descriptors.is_modified 
WHEN 1 THEN 1 ELSE 0
END) * 8 / 1024 AS [Dirty Page (MB)],
    SUM(CASE dm_os_buffer_descriptors.is_modified 
WHEN 1 THEN 0 ELSE 1
END) * 8 / 1024 AS [Clean Page (MB)]
FROM sys.dm_os_buffer_descriptors
INNER JOIN sys.allocation_units ON allocation_units.allocation_unit_id = dm_os_buffer_descriptors.allocation_unit_id
INNER JOIN sys.partitions ON 
((allocation_units.container_id = partitions.hobt_id AND type IN (1,3))
OR (allocation_units.container_id = partitions.partition_id AND type IN (2)))
INNER JOIN sys.objects ON partitions.object_id = objects.object_id
WHERE allocation_units.type IN (1,2,3)
AND objects.is_ms_shipped = 0 
AND dm_os_buffer_descriptors.database_id = DB_ID()
GROUP BY objects.schema_id, objects.name, objects.type_desc
ORDER BY [Total Pages In Buffer] DESC;
