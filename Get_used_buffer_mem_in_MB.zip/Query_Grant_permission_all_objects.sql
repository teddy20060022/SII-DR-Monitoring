USE App_IPLANS
GO

grant VIEW DEFINITION to [CT\IDRBI-SQL-S00-IPLANS-Owners]
where type in (,'V','P','FN','TF')

sp_helprotect
go

declare @login VARCHAR(30) = 'CT\IDRBI-SQL-S00-IPLANS-Owners'

SELECT 'GRANT VIEW DEFINITION ON ' + schema_name(schema_id) + '.' + [name] + ' TO ' + '[' + REPLACE(REPLACE (@login, '[', ''), ']', '') + ']' 
FROM sys.all_objects s 
WHERE type IN ('P', 'V', 'FN', 'TR', 'IF', 'TF') 
   /*
   P - Stored Procedure 
   V - View 
   FN - SQL scalar-function
   TR - Trigger 
   IF - SQL inlined table-valued function
   TF - SQL table-valued function
   U - Table (user-defined)
   */
   AND is_ms_shipped = 0 
ORDER BY s.type, s.name 
GO

