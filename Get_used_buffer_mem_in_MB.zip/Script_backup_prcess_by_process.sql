--alter availability group AOG2_IDRDR_Local_SDB_SP01D remove database SP4_P_IDR_0_GSPSSSRSTempDB

select name,physical_name from sys.master_files
where name LIKE '%content020%'

--I:\SP02P_DATA_MP04\SQLDATA\P_IDR_0_Collab001_Content020_P_SP16\
--I:\SP02P_TLOG_MP04\SQLLOG\P_IDR_0_Collab001_Content020_P_SP16\

--new_folder:
--I:\SP02P_DATA_MP11\SQLDATA\P_IDR_0_Collab001_Content020_P_SP16\

--Address_folder:
 --\\iddriontapfs1.iddri.chevrontexaco.net\SP2016BKP$\BACKUP$IDRBIW12SHPC1A\SP02P

 GO

 --Backup procees
 USE DBATools
-- DECLARE @BACKUP_PASSWORD 	VARCHAR(255)
-- Execute DBATools.dbo.chsp_SLSkey @BACKUP_PASSWORD output
	exec ctsp_BackupDR 
	@DBName='P_IDR_0_Collab001_Content020_P_SP16',
	@ExcludedDBs='"tempdb"',
	@ExcludeLike="'CopyOf%'", 
	@BackupType='F',
	@BackupDir='BKP01',
	@CreateSubDir=1,
	@CompressionLevel=3,
	@RetainDays=5,
	@PerformDBCC=0,
	@DoVerify=0,
	@Verbose=0,
	@DebugOnly=0,
	@BackupMode='N',
	@Threads=3
  -- @encryptionkey=@BACKUP_PASSWORD
-- SET @BACKUP_PASSWORD=null
GO