import-module activedirectory; 
$servers = get-adcomputer -filter {operatingsystem -like "*server*"};
 
foreach ($server in $servers) {
    $services = $null;
    $services = gwmi win32_service -computer $server.name -ErrorAction SilentlyContinue | where {($_.startname -like "*sql.service*")};
 
    if ($services -ne $null) {
        foreach ($service in $services) {
            write-host $server.name - $service.caption - $service.startname;
        }
    }
}
