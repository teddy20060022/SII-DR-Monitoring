--2 GB

--use SP4_DR_IDJ_0_CentralAdmin_Content

--dbcc shrinkfile('SP4_DR_IDJ_0_CentralAdmin_Content_log', 1500) 

--go

select replica_server_name,read_only_routing_url,
secondary_role_allow_connections_desc FROM sys.availability_replicas

go

alter availability group AOG1_IDRDR_SP01D
modify replica ON
'IDJAKW12SHPC1A\SP01D' with 
(secondary_role(ALLOW_CONNECTIONS=NO
))