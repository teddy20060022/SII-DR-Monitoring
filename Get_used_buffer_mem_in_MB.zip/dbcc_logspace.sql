
declare @logspace TABLE(
DATABASENAME nvarchar(200),
LOGSIZE real,	
LOGSPACE real,
Status INT)

--declare @sql_command varchar(100)

--select @sql_command = 'dbcc sqlperf(logspace)'
insert into @logspace EXEC('dbcc sqlperf(logspace)')

select*from @logspace WHERE logspace > 95
GO

