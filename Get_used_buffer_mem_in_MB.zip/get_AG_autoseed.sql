select local_database_name , remote_machine_name,role_desc ,internal_state_desc 
,transfer_rate_bytes_per_second ,transferred_size_bytes 
,database_size_bytes,estimate_time_complete_utc ,failure_message ,failure_time_utc, 
is_compression_enabled  from sys.dm_hadr_physical_seeding_stats
GO

select*from sys.dm_hadr_automatic_seeding
where start_time > '2018-06-26'

SELECT start_time,
    ag.name,
    db.database_name,
    current_state,
    performed_seeding,
    failure_state,
    failure_state_desc
FROM sys.dm_hadr_automatic_seeding autos 
    JOIN sys.availability_databases_cluster db 
        ON autos.ag_db_id = db.group_database_id
    JOIN sys.availability_groups ag 
        ON autos.ag_id = ag.group_id
		where  current_state='SEEDING'
		AND start_time > '2019-06-30' AND current_state='SEEDING'

--select * from sys.dm_hadr_physical_seeding_stats;  

 
SELECT
   ag.name AS aag_name,
   ar.replica_server_name,
   d.name AS database_name,
   has.current_state,
   has.failure_state_desc AS failure_state,
   has.error_code,
   has.performed_seeding,
   has.start_time,
   has.completion_time,
   has.number_of_attempts
FROM sys.dm_hadr_automatic_seeding AS has
JOIN sys.availability_groups AS ag
   ON ag.group_id = has.ag_id
JOIN sys.availability_replicas AS ar
   ON ar.replica_id = has.ag_remote_replica_id
JOIN sys.databases AS d
   ON d.group_database_id = has.ag_db_id
WHERE ar.replica_server_name='AOG1_IDRDR_SP02D'
