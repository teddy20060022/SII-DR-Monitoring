alter availability group AOG1_IDRDR_SP02D remove database G00P_IDR_T00A01_Collab001_Content002_P_SP16

go

select AR.replica_server_name, DBR.database_name, DBR.is_database_joined
from sys.dm_hadr_database_replica_cluster_states AS DBR
join sys.availability_replicas as AR
ON DBR.replica_id=AR.replica_id