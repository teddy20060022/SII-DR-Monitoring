DECLARE @counter SMALLINT
DECLARE @dbname VARCHAR(100)

CREATE TABLE #BackupDetailsDaily(
    [HostWithInstance] [nvarchar](50),
    [DBName] [nvarchar](100),
    [BkupStartTime] [datetime],
    [BkupFinishTime] [datetime],
    [BkupType] [varchar](1),
    [BkupLocation] [nvarchar](250),
    [BkupSize_MB] [DECIMAL](15,2)
)

--Loop through all DB's
SELECT @counter = MAX(dbid) FROM master..sysdatabases WHERE name NOT IN ('tempdb')
WHILE @counter > 0
BEGIN

    SELECT @dbname = name FROM master..sysdatabases WHERE dbid = @counter

    INSERT INTO #BackupDetailsDaily (DBName, BkupStartTime, BkupFinishTime, BkupType, BkupSize_MB, BkupLocation) 
    select top 1 b.database_name, b.backup_start_date, b.backup_finish_date, b.type, CAST(((b.compressed_backup_size)* 0.00000095367432) AS DECIMAL(15,2)), a.physical_device_name 
    from msdb.dbo.backupmediafamily a join msdb.dbo.backupset b
    on (a.media_set_id=b.media_set_id)
    where database_name = @dbname and b.type = 'L'
    order by b.backup_start_date desc
    
    SET @counter = @counter - 1
END

UPDATE #BackupDetailsDaily SET HostWithInstance = @@SERVERNAME

SELECT * FROM #BackupDetailsDaily
DROP TABLE #BackupDetailsDaily

