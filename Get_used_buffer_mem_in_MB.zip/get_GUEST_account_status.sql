if EXISTS (select * from tempdb..sysobjects where name ='Guest_Account')
       begin
              drop table tempdb..Guest_Account
       end

create table tempdb..Guest_Account (Dname varchar(100), Uname varchar(100), Revok varchar(100)) 

--use master
DECLARE @dbname7 varchar(150)
declare @sqlstring4 varchar (250)
declare @sqlstring5 varchar (250)
DECLARE dnames_cursor CURSOR

for
select substring(name,1,50) as database_name from sys.databases
                     where has_dbaccess(name) = 1 -- Only look at databases to which we have access
open dnames_cursor

--SET @dbname = 'one'
FETCH NEXT FROM dnames_cursor INTO @dbname7
WHILE (@@FETCH_STATUS <> -1)
BEGIN
   IF (@@FETCH_STATUS <> -2)

       begin

              

       
              set @sqlstring4 = 'insert into tempdb..Guest_Account (Dname, Uname,Revok) '
              set @sqlstring4 = @sqlstring4 + 'select ''' + @dbname7 + ''', u.name,u.hasdbaccess '
              set @sqlstring4 = @sqlstring4 + 'from [' + @dbname7 +']..sysusers as u '
              set @sqlstring4 = @sqlstring4 + 'where u.name = ''guest'''

              --print @sqlstring4
              exec (@sqlstring4)
       
       end
      FETCH NEXT FROM dnames_cursor INTO @dbname7
END
CLOSE dnames_cursor
DEALLOCATE dnames_cursor

select @@SERVERNAME, Dname,Uname,
(case when Revok=0 then 'Revoke' 
 when Revok=1 then 'Active' 

end) as  Status

from tempdb..Guest_Account where Uname = 'guest'
