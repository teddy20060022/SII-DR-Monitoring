sp_trace_setstatus @treaceid, @status=0

go

select*from sys.fn_trace_getinfo(0)
go

USE DBAUtils
SELECT * INTO _Trace20190126 FROM ::fn_trace_gettable('G:\MSSQL10_50.SHR01P\MSSQL\Log\log_389.trc', DEFAULT)
GO


DECLARE @RC int, @TraceID int, @on BIT
EXEC @rc = sp_trace_create @TraceID output, 2, N'C:\path\file'
SELECT RC = @RC, TraceID = @TraceID
-- Follow Common SQL trace event list and common sql trace
-- tables to define which events and table you want to capture
SELECT @on = 1
EXEC sp_trace_setevent @TraceID, 128, 1, @on
-- (128-Event Audit Database Management Event, 1-TextData table column)
EXEC sp_trace_setevent @TraceID, 128, 11, @on
EXEC sp_trace_setevent @TraceID, 128, 14, @on
EXEC sp_trace_setevent @TraceID, 128, 35, @on 
EXEC @RC = sp_trace_setstatus @TraceID, 1
GO
