DECLARE @LoginName sysname;

DECLARE @DatabaseName sysname;

DECLARE @SQL NVARCHAR(4000);

DECLARE @sid VARCHAR(255);

SET @LoginName = 'web_mars';

SET @sid = (SELECT sid FROM sys.server_principals WHERE [name] = @LoginName);

CREATE TABLE #Mappings (

  DatabaseName sysname,

  UserName sysname);

DECLARE cursDatabases CURSOR FAST_FORWARD FOR SELECT name FROM sys.databases where state=0;

OPEN cursDatabases;

FETCH NEXT FROM cursDatabases INTO @DatabaseName;

WHILE (@@FETCH_STATUS = 0)

BEGIN

SET @SQL = 'INSERT INTO #Mappings (DatabaseName, UserName)

             SELECT ''' + @DatabaseName + ''', name

             FROM [' + @DatabaseName + '].sys.database_principals

             WHERE sid = ''' + @sid + ''';';

EXEC(@SQL);

FETCH NEXT FROM cursDatabases INTO @DatabaseName;

END

CLOSE cursDatabases;

DEALLOCATE cursDatabases;

SELECT * FROM #Mappings;
DROP TABLE #Mappings;
