CREATE TABLE #explogin ( servername NVARCHAR(MAX)
						,name NVARCHAR(MAX)
						,DBName varchar(100)
						,DaysExpiration INT
						,DaysApplied INT
						,IsExpChecked INT
						,DBRole varchar(100) )

CREATE TABLE #DBMapping(LoginName varchar(150),
						DBName varchar(100),
						UserName varchar(150),
						AliasName varchar(50)
						)
INSERT INTO #DBMapping
 EXEC sp_msloginmappings 
 
INSERT INTO #explogin 
	SELECT CONVERT(CHAR, SERVERPROPERTY('Servername'))--col01 for servername
	,SL.name AS UserID --col02 for name
	,DB.DBName --col03 for DBName
	,CONVERT(INT, LOGINPROPERTY (SL.NAME, CAST('DaysUntilExpiration' AS NVARCHAR)))   --col04 for DaysExpiration
	,DATEDIFF(day,CONVERT(datetime,LOGINPROPERTY(name, 'PasswordLastSetTime')),getdate())  --col05 for DaysApplied
	,SL.is_expiration_checked  --col06 for IsExpChecked
	,case when US.Db_role is null then 'Public' else  US.Db_role  end
	FROM sys.sql_logins SL 
	INNER JOIN #DBMapping DB ON SL.name=DB.UserName and  SL.is_disabled = 0
	left join [DBAUtils].[dbo].[Sql_User_Priviledge] US ON SL.name = US.SQl_Login AND DB.DBName = replace(replace(US.Db_name,'[',''),']','')
	where SL.name not in('web_intelatrac','web_intelatrac42','web_dmisaet','ARAdmin','SmartIT_System','openfire') 
	order by DB.DBName

select
servername ,
name as 'SQLLogin',
DBName,
DaysApplied,
DBRole
from  #explogin 

drop table #explogin 
drop table #DBMapping
