select DB_NAME(database_id) AS DB
,login_name
,nt_domain,
NT_user_name
,status
,HOST_NAME,
program_name
,COUNT(*) as Connection
from sys.dm_exec_sessions
where database_id > 0
group by database_id,login_name,status,host_name,program_name,nt_domain,nt_user_name