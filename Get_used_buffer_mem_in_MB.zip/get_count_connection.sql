select db_name(dbid) as dbname,
count(dbid) as NumberConnection,
loginame as LoginName
from
 sys.sysprocesses
 where dbid > 0
 group by dbid, loginame