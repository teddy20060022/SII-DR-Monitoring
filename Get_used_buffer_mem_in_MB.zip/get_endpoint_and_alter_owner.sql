USE [master]
GO

select SUSER_NAME(principal_id)
AS endpoint_owner, name as endpoint_name
from sys.database_mirroring_endpoints

grant connect on endpoint::Hadr_endpoint TO [CT\s-IDR-P-SP4-0-SQ00]

alter authorization on endpoint::Hadr_endpoint TO [CT\s-IDR-P-SP4-0-SQ00]

alter endpoint hadr_endpoint STATE=STARTED

go

create endpoint [sb_endpoint]
state=started
AS TCP (listener_port=4022, listener_ip=ALL)
for service_broker(authentication=WINDOWS)