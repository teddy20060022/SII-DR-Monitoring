alter availability group [AOG1_IDRDR_SP01D] REMOVE DATABASE [KGIC_AOG_01]

alter database [KGIC_AOG_01] set hadr off

restore database KGIC_AOG_01 with recovery

alter database G00P_IDR_T00A01_Collab001_Content002_P_SP16 SET HADR AVAILABILITY GROUP = [AOG1_IDRDR_SP02D] 

select r.replica_server_name,
r.endpoint_url,
rs.connected_state_desc,rs.last_connect_error_description, 
rs.last_connect_error_number, rs.last_connect_error_timestamp
from sys.dm_hadr_availability_replica_states rs JOIN sys.availability_replicas r
ON rs.replica_id=r.replica_id where rs.is_local=1 

GO

select
database_name,
is_failover_ready
from sys.dm_hadr_database_replica_cluster_states where replica_id IN (select replica_id from sys.availability_replicas)        

go

SELECT EPS.name, SPS.STATE, CONVERT(nvarchar(38), SUSER_NAME(SPS.grantor_principal_id))AS [GRANTED BY], SPS.TYPE AS PERMISSION, CONVERT(nvarchar(46),SUSER_NAME(SPS.grantee_principal_id))AS [GRANTED TO] 
FROM sys.server_permissions SPS , sys.endpoints EPS WHERE SPS.major_id = EPS.endpoint_id AND name = 'Hadr_endpoint' 
ORDER BY Permission,[GRANTED BY], [GRANTED TO];
  

                                                                      