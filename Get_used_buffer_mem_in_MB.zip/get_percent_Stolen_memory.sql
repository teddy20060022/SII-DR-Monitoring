update PCM_SUBMISSION_MASTER set EXPENDED_DATE = '0.00000' where DOC_NO = '2019-09-0023' and EXPENDED_DATE = '37005.42000'

go

select*from sys.dm_os_performance_counters where counter_name 
 in ('Stolen Server Memory (KB)','Batch Requests/sec' ) 
 
 GO
 
 82960278
25158800
 
 GO           
 
 SELECT Now = GETDATE()
    ,StolenMemory = (
        SELECT cntr_value
        FROM sys.dm_os_performance_counters
        WHERE [counter_name] IN ('Stolen Server Memory (KB)')
        )
    ,StolenMemoryPercent = 100.0 * (
        SELECT cntr_value
        FROM sys.dm_os_performance_counters
        WHERE [counter_name] IN ('Stolen Server Memory (KB)')
        ) / (
        SELECT cntr_value
        FROM sys.dm_os_performance_counters
        WHERE [counter_name] IN ('Total Server Memory (KB)')
        )
                                                                                                 ')                                                                                                      ')