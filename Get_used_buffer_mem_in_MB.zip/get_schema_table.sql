--use E1_QRA

--select*from sys.objects where name like'%f00092%'

--select top(1) * from dbo.F00092

--select*from sys.schemas

select db_NAME() as 'database',ss.name as 'schema', so.name as 'object'
from sys.objects so
inner join sys.schemas ss on ss.schema_id=so.schema_id
where so.name='f00092'
