select local_database_name , remote_machine_name,role_desc ,internal_state_desc 
,transfer_rate_bytes_per_second ,transferred_size_bytes 
,database_size_bytes,estimate_time_complete_utc ,failure_message ,failure_time_utc, 
is_compression_enabled  from sys.dm_hadr_physical_seeding_stats
GO

alter availability group AOG1_IDRPROD_SP02P 
modify replica ON 'IDRBIW12SHPC1A\SP02P'
with (SEEDING_MODE=AUTOMATIC)

GO

alter availability group AOG1_IDRPROD_SP02P 
grant create any database
