select @@servername as 'instance', DB_NAME() as 'database',
name,
type_desc,modify_date
 from sys.objects where name ='IMM_ItemMaster_UpdateDaily'