grant alter ANY availability group to [NT AUTHORITY\SYSTEM]
GO
grant connect SQL to [NT AUTHORITY\SYSTEM]
GO
grant view server state to [NT AUTHORITY\SYSTEM]