DECLARE @recovery_model_desc varchar(60)

SELECT @recovery_model_desc = recovery_model_desc
FROM sys.databases
WHERE name = 'dbname'
IF @recovery_model_desc <> 'SIMPLE'
    ALTER DATABASE dbname SET RECOVERY SIMPLE;
DBCC SHRINKFILE( dbname_LOG, 2);
IF @recovery_model_desc <> 'SIMPLE'
BEGIN
    IF @recovery_model_desc = 'FULL'
        ALTER DATABASE dbname SET RECOVERY FULL
    ELSE
        ALTER DATABASE dbname SET RECOVERY BULK_LOGGED
END /*IF*/
