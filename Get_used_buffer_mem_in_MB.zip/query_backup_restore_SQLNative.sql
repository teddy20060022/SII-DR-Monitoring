 [ServiceAward] 
--IDRBIW12AHS12\SDV2
BACKUP DATABASE [ServiceAward] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\ServiceAward\Dev\IDRBIW12AHS12_ServiceAward_full_12042019.bak' 
WITH NOFORMAT, NOINIT,   
NAME = N'ServiceAward-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

--IDRBIW12AHS25\SCPD2
BACKUP DATABASE [ServiceAward] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\ServiceAward\Prod\IDRBIW12AHS25__ServiceAward_full_12042019.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'ServiceAward-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

[App_IBUTPW] 
--IDRBIW12AHS12\SDV2
BACKUP DATABASE [App_IBUTPW] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\App_IBUTPW\Dev\IDRBIW12AHS12_App_IBUTPW_full_12042019.bak' 
WITH NOFORMAT, NOINIT,   
NAME = N'App_IBUTPW-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO

--IDRBIW12AHS25\SCPD2
BACKUP DATABASE [App_IBUTPW] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\App_IBUTPW\Prod\IDRBIW12AHS25__App_IBUTPW_full_12042019.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'App_IBUTPW-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO


[BPMIGAS_FQR] 
--IDRBIW12AHS12\SDV2
BACKUP DATABASE [BPMIGAS_FQR] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\BPMIGAS_FQR\Dev\IDRBIW12AHS12_BPMIGAS_FQR_full_12042019.bak' 
WITH NOFORMAT, NOINIT,   
NAME = N'BPMIGAS_FQR-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO


--IDRBIW12AHS24\SCPD2
BACKUP DATABASE [BPMIGAS_FQR] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\BPMIGAS_FQR\Prod\IDRBIW12AHS24_BPMIGAS_FQR_full_12042019.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'BPMIGAS_FQR-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO


[SOTFQR] 
--IDRBIW12AHS24\SCPD2
BACKUP DATABASE [SOTFQR] 
TO  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\SOTFQR\Prod\IDRBIW12AHS24_SOTFQR_full_12042019.bak' 
WITH NOFORMAT, NOINIT,  
NAME = N'SOTFQR-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO



//RESTORING

IDRBIW12AHS24\SCPD1

RESTORE DATABASE [BPMIGAS_FQR_15042019] 
FROM  DISK = N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\BPMIGAS_FQR\Prod\IDRBIW12AHS24_BPMIGAS_FQR_full_12042019.bak' 
WITH  FILE = 1,  
MOVE N'BPMIGAS_FQR_rest' TO N'G:\SQL_DATA_G2\Data\BPMIGAS_FQR_15042019.mdf',  
MOVE N'BPMIGAS_FQR_rest_log' TO N'G:\SQL_TLOG_G1\Log\BPMIGAS_FQR_rest_log_15042019.ldf',    
NOUNLOAD,  STATS = 5

GO

RESTORE DATABASE [SOTFQR_15042019] 
FROM  DISK = 
N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\SOTFQR\Prod\IDRBIW12AHS24_SOTFQR_full_12042019.bak' 
WITH  FILE = 1,  
MOVE N'SOTFQR' TO N'G:\SQL_DATA_G2\Data\SOTFQR_15042019.MDF',  
MOVE N'SOTFQR2' TO N'G:\SQL_DATA_G2\Data\SOTFQR2_15042019.ndf',  
MOVE N'SOTFQR3' TO N'G:\SQL_DATA_G2\Data\SOTFQR3_15042019.ndf',
MOVE N'SOTFQR_log' TO N'G:\SQL_TLOG_G1\Log\SOTFQR_log_15042019.ldf',  
NORECOVERY,  NOUNLOAD,  STATS = 5

GO

RESTORE DATABASE [App_IBUTPW_15042019] 
FROM  DISK = 
N'\\iddriontapfs1.iddri.chevrontexaco.net\sql_backup$\App_IBUTPW\Prod\IDRBIW12AHS25__App_IBUTPW_full_12042019.bak' 
WITH  FILE = 1,  
MOVE N'APP_IBUTPW' TO N'H:\SQL_DATA_H2\Data\APP_IBUTPW_15042019_.mdf',  
MOVE N'APP_IBUTPW_Log' TO N'H:\SQL_TLOG_H1\Log\APP_IBUTPW_log_15042019.ldf',  
NORECOVERY,  NOUNLOAD,  STATS = 5

GO
