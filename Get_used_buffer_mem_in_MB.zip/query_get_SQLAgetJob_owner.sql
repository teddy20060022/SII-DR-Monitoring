select s.name, l.name from msdb..sysjobs s
left join master.sys.syslogins l ON s.owner_sid=l.sid