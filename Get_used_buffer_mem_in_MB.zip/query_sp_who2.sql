declare @spwho2 TABLE(
SPID	INT,
Status	varchar(100),
Login varchar(100),	
HostName varchar(100),
BlkBy varchar(20),
DBName	varchar(50),
Command	varchar(200),
CPUTime	bigint,
DiskIO	 bigint,
LastBatch	varchar(20),
ProgramName	varchar(100),
SPID2 INT,
REQUESTID INT
)
insert @spwho2
exec sp_who2

select*from @spwho2 WHERE login LIKE '%kgic%'
GO

--select*from sys.server_permissions
--where grantor_principal_id=
--(
--select principal_id from sys.server_principals where name LIKE '%kgic%'
--)

----select*from sys.server_principals
--GO

--alter authorization on database::SP4_P_IDR_0_GSPSManagedMetadata TO sa

--select name, suser_sname(owner_sid) AS DBOwner from sys.databases 

--select*from sys.syslogins where name IN ('ct\!diuz','ct\!kgic')

--go

----select servicename, status_desc, service_account from sys.dm_server_services

--GO

--alter authorization on endpoint :: Hadr_endpoint TO [CT\s-IDR-P-SP4-0-SQ00]

--go

--kill 129
--kill 1718