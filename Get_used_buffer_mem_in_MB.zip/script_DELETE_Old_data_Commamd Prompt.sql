forfiles -p "\iddriontapfs1.iddri.chevrontexaco.net\SP2016BKP$\BACKUP$IDRBIW12SHPC1A\SP02P\"  -s -m *.* -d 3 -c "cmd /c del @path"
