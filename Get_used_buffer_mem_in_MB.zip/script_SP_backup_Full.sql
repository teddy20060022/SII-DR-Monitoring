-- DECLARE @BACKUP_PASSWORD 	VARCHAR(255)
-- Execute DBATools.dbo.chsp_SLSkey @BACKUP_PASSWORD output
exec ctsp_BackupDR @DBName='SP4_DR_IDJ_0_GSPSUserProfile',
	--@ExcludedDBs='"Master","MSDB","Model"',
	@ExcludeLike="'CopyOf%'", 
	@BackupType='F',
	@BackupDir='\\iddriontapfs1.iddri.chevrontexaco.net\SP2016BKP$\BACKUP$IDDRIW12SHPC1B\SP01D\',
	@CreateSubDir=1,
	@RetainDays=6,
	@PerformDBCC=0,
	@DoVerify=1,
	@Verbose=0,
	@DebugOnly=0,
	@BackupMode='N',
	@Threads=1
  -- @encryptionkey=@BACKUP_PASSWORD
-- SET @BACKUP_PASSWORD=null

--  Database backups are NOT ENCRYPTED.
	
	exec DBATools.dbo.ctsp_BackupDR
	@DBName='G00P_IDR_T00A01_Collab001_Content001_P_SP16',
	@BackupType='L',
	@BackupDir='BKP01',
	@CreateSubDir=1,
	@RetainDays=60,
	@PerformDBCC=0,
	@DoVerify=1,
	@Verbose=0,
	@DebugOnly=0,
	@BackupMode='N',
	@Threads=1