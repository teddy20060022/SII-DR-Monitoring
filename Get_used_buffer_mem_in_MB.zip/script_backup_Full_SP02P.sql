--Batch 01

/** Duration 18:25:36 **/

-- DECLARE @BACKUP_PASSWORD 	VARCHAR(255)
-- Execute DBATools.dbo.chsp_SLSkey @BACKUP_PASSWORD output
	exec ctsp_BackupDR 
	@DBName='*',
	@ExcludedDBs='
	"tempdb",
	"DBATools",
	"DBATools2",
	"Dist_KGIC_AOG_01",
	"G00P_IDR_T00A01_Collab001_Content001_P_SP16",
	"G00P_IDR_T00A01_Collab001_Content002_P_SP16",
	"G00P_IDR_T00A01_Collab001_Content003_P_SP16",
	"G00P_IDR_T00A01_Collab001_Content004_P_SP16",
	"G00P_IDR_T00A01_Collab001_Content005_P_SP16",
	"H_IDR_0_CollabHA1_Content001_P_SP16",
	"P_IDR_0_Collab001_Content006_P_SP16",
	"P_IDR_0_Collab001_Content007_P_SP16",
	"P_IDR_0_Collab001_Content008_P_SP16",
	"P_IDR_0_Collab001_Content009_P_SP16",
	"P_IDR_0_Collab001_Content010_P_SP16",
	"P_IDR_0_Collab001_Content011_P_SP16",
	"P_IDR_0_Collab001_Content012_P_SP16",
	"P_IDR_0_Collab001_Content044_P_SP16"
	',
	@ExcludeLike="'CopyOf%'", 
	@BackupType='F',
	@BackupDir='BKP01',
	@CreateSubDir=1,
	@CompressionLevel=3,
	@RetainDays=6,
	@PerformDBCC=0,
	@DoVerify=0,
	@Verbose=0,
	@DebugOnly=0,
	@BackupMode='N',
	@Threads=1
  -- @encryptionkey=@BACKUP_PASSWORD
-- SET @BACKUP_PASSWORD=null
GO

--Batch 02
-- DECLARE @BACKUP_PASSWORD 	VARCHAR(255)
-- Execute DBATools.dbo.chsp_SLSkey @BACKUP_PASSWORD output
	exec ctsp_BackupDR 
	@DBName='*',
	@ExcludedDBs='
	"H_IDR_0_CollabHA1_Content001_P_SP16",
	"LiteSpeedLocal",
	"master",
	"model",
	"msdb",
	"P_IDR_0_Collab001_Content013_P_SP16",
	"P_IDR_0_Collab001_Content014_P_SP16",
	"P_IDR_0_Collab001_Content016_P_SP16",
	"P_IDR_0_Collab001_Content017_P_SP16",
	"P_IDR_0_Collab001_Content019_P_SP16",
	"P_IDR_0_Collab001_Content020_P_SP16",
	"P_IDR_0_Collab001_Content021_P_SP16",
	"P_IDR_0_Collab001_Content022_P_SP16",
	"P_IDR_0_Collab001_Content023_P_SP16",
	"P_IDR_0_Collab001_Content024_P_SP16",
	"P_IDR_0_Collab001_Content025_P_SP16",
	"P_IDR_0_Collab001_Content026_P_SP16",
	"P_IDR_0_Collab001_Content027_P_SP16",
	"P_IDR_0_Collab001_Content028_P_SP16",
	"P_IDR_0_Collab001_Content029_P_SP16",
	"P_IDR_0_Collab001_Content030_P_SP16",
	"P_IDR_0_Collab001_Content031_P_SP16",
	"P_IDR_0_Collab001_Content032_P_SP16",
	"P_IDR_0_Collab001_Content033_P_SP16",
	"P_IDR_0_Collab001_Content034_P_SP16",
	"P_IDR_0_Collab001_Content035_P_SP16",
	"P_IDR_0_Collab001_Content036_P_SP16",
	"P_IDR_0_Collab001_Content037_P_SP16",
	"P_IDR_0_Collab001_Content038_P_SP16",
	"P_IDR_0_Collab001_Content039_P_SP16",
	"P_IDR_0_Collab001_Content040_P_SP16",
	"P_IDR_0_Collab001_Content041_P_SP16",
	"P_IDR_0_Collab001_Content042_P_SP16",
	"P_IDR_0_Collab001_Content043_P_SP16",
	"P_IDR_0_Test",
	"SP4_P_IDR_0_Collab_Content001",
	"SP4_P_IDR_0_SPOps_Content001"
	',
	@ExcludeLike="'CopyOf%'", 
	@BackupType='F',
	@BackupDir='BKP01',
	@CreateSubDir=1,
	@CompressionLevel=3,
	@RetainDays=6,
	@PerformDBCC=0,
	@DoVerify=0,
	@Verbose=0,
	@DebugOnly=0,
	@BackupMode='N',
	@Threads=1
  -- @encryptionkey=@BACKUP_PASSWORD
-- SET @BACKUP_PASSWORD=null
GO