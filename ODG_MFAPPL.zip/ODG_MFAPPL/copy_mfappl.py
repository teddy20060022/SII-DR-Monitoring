# -*- coding: utf-8 -*-
"""
Created on Wed Sep 25 15:30:00 2019

@author: Muhammmad Tedi Sopyan
"""
import os
import cx_Oracle
os.chdir("C:\\instantclient_19_3")
#source, prod, monitoriing, cur = None, None, None, None
try: 
    #Server Production MFAPPL
    con_prod = cx_Oracle.connect('DBA_USER/DBA67890@192.168.132.22/MFPROD')
    print ("Connected To DBA_USER " + con_prod.version)
    cur_prod = con_prod.cursor()
    sql_grap = "select A.thread# ||'_'||A.sequence#||'_'||B.resetlogs_id||'.arc' filename, \
                A.FIRST_TIME start_time, \
                B.NEXT_TIME end_time, \
                round(B.blocks * B.block_size/1024/1024,2), \
                B.status, \
                B.APPLIED,\
                B.DELETED, \
                B.DEST_ID, \
                B.COMPLETION_TIME, \
                A.sequence# \
                from v$log_history A, v$archived_log B \
                where A.sequence# = B.sequence# and A.FIRST_TIME >= trunc(sysdate-1) and A.FIRST_TIME <= (sysdate) \
                AND B.DEST_ID=2 ORDER BY A.FIRST_TIME ASC"#and rownum = 1"
    result_set = cur_prod.execute(sql_grap)
    result_list = result_set.fetchall()
    
    # Connect to Server Monitoring
    monitoring = cx_Oracle.connect('monitor/monitor@172.17.30.77/XE')
    print ("Connected To MONITOR " + monitoring.version)
    cur = monitoring.cursor()
        
    if result_set.rowcount == 0:
        """
        sql_insert = 'insert into MONITORING_DGM VALUES(\'{}\',\'{}\',{},\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'Process Completed\',SYSDATE-1,\'{}\',\'{}\',\'{}\',\'{}\')'.format(modul_define.mf_system, modul_define.backup, modul_define.mf_seq_b, modul_define.mf_schema, start_time, status, end_time, elapsed_time, file_name, file_size, applied, deleted, DEST_ID, COMPLETION_TIME)
        cur.execute(sql_insert)  
        monitoring.commit()
        """
        print('No row returned')
    else:

        #insert Into Oracle
        for row in result_list:
            file_name = row[0]
            print(r'File Name    : {}'.format(file_name))
            v_status = row[4]
            if v_status =='A':
                status = "Available"
            elif v_status == 'D':
                status = "Deleted"
            elif v_status =='U':
                status = "Unavailable";
            else:
                status = "Expired"
            
            print(r'Status          : {}'.format(status))
            start_time = row[1]
            print(r'Start Time      : {}'.format(start_time))
            end_time = row[2]
            print(r'End Time        : {}'.format(end_time))
            elapsed_time = end_time - start_time
            print(r'Elapsed Time    : {}'.format(elapsed_time))
            file_size = row[3]
            print(r'File Size       : {}'.format(file_size))
            applied = row[5]
            print(r'Applied         : {}'.format(applied))
            deleted = row[6]
            print(r'Deleted         : {}'.format(deleted))
            DEST_ID = row[7]
            print(r'DEST_ID         : {}'.format(DEST_ID))
            COMPLETION_TIME = row[8]
            print(r'COMPLETION_TIME : {}'.format(COMPLETION_TIME))
            seq = row[9]
            print(r'sequence#       : {}'.format(seq))
            
            sql_insert = 'insert into MONITORING_DGM VALUES(\'MFL\',\'C\',{},\'MFAPPL\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'{}\',\'Process Completed\',SYSDATE-1,\'{}\',\'{}\',\'{}\',\'{}\')'.format(seq, start_time, status, end_time, elapsed_time, file_name, file_size, applied, deleted, DEST_ID, COMPLETION_TIME)
            cur.execute(sql_insert)  
            monitoring.commit()
            print(r'Inserting To Monitoring : Successfuly')
          
except cx_Oracle.DatabaseError as e: 
    print("There is a problem with Oracle", e) 

finally: 
    # Close Connection Server Production MFAPPL
    """
    if con_prod:
        con_prod.close()
    if cur_prod:
        cur_prod.close()
        
    # Close Connection Server Monitoring    
    if monitoring:
        monitoring.close()
    if cur:
        cur.close()
    """