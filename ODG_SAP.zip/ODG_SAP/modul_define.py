# -*- coding: utf-8 -*-
"""
Created on Sat Sep 21 15:40:18 2019

@author: MuhammadSoSis
"""

from datetime import datetime
dateTimeObj   = datetime.now()
timestampStr1 = dateTimeObj.strftime("%b %d %Y %H:%M:%S")
timestampStr2 = dateTimeObj.strftime("%b %d %Y")
timestampStr3 = dateTimeObj.strftime("%Y%m%d")
tanggal='{}'.format(timestampStr3)
#print('Current Timestamp : ', timestampStr1)

client       = 'C:\instantclient_19_3'
conn_monitor = 'monitor/monitor@172.17.30.77/XE'
conn_mfappl  = 'DBA_USER/DBA67890@192.168.132.22/MFPROD'

backup  = 'B'
copy    = 'C'
restore = 'R'

def MFL():
    print("Schema MFAPPL")

mf_system = 'MFL'
mf_schema = 'MFAPPL'
mf_seq_b  = 'SEQ_MFLB.NEXTVAL'
mf_seq_r  = 'SEQ_MFLR.NEXTVAL'
mf_seq_c  = 'SEQ_MFLC.NEXTVAL'

def SAP():
    print("Schema SAP")

sap_system = 'SAP'
sap_schema = 'SAP'
sap_seq_b  = 'SEQ_SAPB.NEXTVAL'
sap_seq_r  = 'SEQ_SAPR.NEXTVAL'
sap_seq_c  = 'SEQ_SAPC.NEXTVAL'