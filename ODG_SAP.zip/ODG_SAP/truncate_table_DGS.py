# -*- coding: utf-8 -*-
"""
Created on Fri Sep 27 16:26:59 2019

@author: dipopamsuper
"""

import os
import cx_Oracle
os.chdir("C:\\instantclient_19_3")
try: 
    #Server MONITOR
    monitoring = cx_Oracle.connect('monitor/monitor@172.17.30.77/XE')
    print ("Connected To MONITOR " + monitoring.version)
    cur = monitoring.cursor()
    sql_grap = "TRUNCATE TABLE MONITOR.MONITORING_DGS REUSE STORAGE"
    cur.execute(sql_grap)
    print(r'Truncate Table Done')
except cx_Oracle.DatabaseError as e: 
    print("There is a problem with Oracle", e) 

finally: 
    if monitoring:
        monitoring.close()