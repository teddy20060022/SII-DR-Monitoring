# -*- coding: utf-8 -*-
"""
Created on Sat Sep 21 15:40:18 2019

@author: MuhammadSoSis
"""

from datetime import datetime
dateTimeObj = datetime.now()
timestampStr1 = dateTimeObj.strftime("%b %d %Y %H:%M:%S")
timestampStr2 = dateTimeObj.strftime("%b %d %Y")
timestampStr3 = dateTimeObj.strftime("%Y%m%d")
tanggal='{}'.format(timestampStr3)
#print('Current Timestamp : ', timestampStr1)

client = 'C:\Program Files\Oracle\instantclient_19_3'
connector = 'USER_DEMO/oracle@192.168.0.101/DB11G'
user = 'USER_DEMO'
path_name = 'D:\Project\BSI\BACKUP\\'
backup = 'B'
copy = 'C'
restore = 'R'

def aca():
    print("Schema aca")
aca_file_name = '{}_expdp_pdbaca02.log'.format(timestampStr3)
aca_value='{}{}'.format(path_name,aca_file_name)
aca_system = 'ACA'
aca_schema = 'pdbaca02'
aca_seq_b = 'SEQ_ACAB.NEXTVAL'

def sta():
    print("Schema ST1")
sta_file_name = '{}_expdp_PDBSTGACACON01.log'.format(timestampStr3)
sta_value='{}{}'.format(path_name,sta_file_name)
sta_system = 'ST1'
sta_schema = 'PDBSTGACACON01'
sta_seq_b = 1

def stb():
    print("Schema ST2")
stb_file_name = '{}_expdp_PDBLCBE_ADMIN.log'.format(timestampStr3)
stb_value='{}{}'.format(path_name,stb_file_name)
stb_system = 'ST2'
stb_schema = 'PDBLCBE_ADMIN'
stb_seq_b = 1

def stc():
    print("Schema ST3")
stc_file_name = '{}_expdp_OLSS_MFAPPL.log'.format(timestampStr3)
stc_value='{}{}'.format(path_name,stc_file_name)
stc_system = 'ST3'
stc_schema = 'OLSS_MFAPPL'
stc_seq_b = 1