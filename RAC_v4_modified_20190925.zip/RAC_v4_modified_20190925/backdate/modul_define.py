# -*- coding: utf-8 -*-
"""
Created on Sat Sep 21 15:40:18 2019

@author: MuhammadSoSis
"""

from datetime import datetime
dateTimeObj = datetime.now()
timestampStr1 = dateTimeObj.strftime("%b %d %Y %H:%M:%S")
timestampStr2 = dateTimeObj.strftime("%b %d %Y")
timestampStr3 = dateTimeObj.strftime("%Y%m%d")
tanggal='{}'.format(timestampStr3)
#print('Current Timestamp : ', timestampStr1)

client = 'C:\instantclient_19_3'
connector = 'monitor/monitor@172.17.30.77/XE'
user = 'MONITOR'
path_name = 'C:\\symscripts\\logs\\'
path_name_restore = '\\\\172.24.2.36\\c$\\syncscripts\\logs\\'
file_name_copy = '{}_backup.log'.format(timestampStr3)
directory_copy = '{}{}'.format(path_name,file_name_copy)

backup = 'B'
copy = 'C'
restore = 'R'

def aca():
    print("Schema aca")
aca_file_name = '{}_expdp_pdbaca02.log'.format(timestampStr3)
aca_file_name_restore = '{}_impdp_pdbaca02.log'.format(timestampStr3)
aca_value='{}{}'.format(path_name,aca_file_name)
aca_value_restore ='{}{}'.format(path_name_restore,aca_file_name_restore)
aca_value_start = 'start data transfer C:\\symscripts\\1_4_1_Transfer.bat pdbaca02'
aca_value_end = 'completed C:\\symscripts\\1_4_1_Transfer.bat pdbaca02'
aca_system = 'ACA'
aca_schema = 'pdbaca02'
aca_seq_b = 'SEQ_ACAB.NEXTVAL'
aca_seq_r = 'SEQ_ACAR.NEXTVAL'
aca_seq_c = 'SEQ_ACAC.NEXTVAL'

def sta():
    print("Schema ST1")
sta_file_name = '{}_expdp_PDBSTGACACON01.log'.format(timestampStr3)
sta_file_name_restore = '{}_impdp_PDBSTGACACON01.log'.format(timestampStr3)
sta_value='{}{}'.format(path_name,sta_file_name)
sta_value_restore='{}{}'.format(path_name_restore,sta_file_name_restore)
sta_value_start = 'start data transfer C:\\symscripts\\1_4_1_Transfer.bat PDBSTGACACON01'
sta_value_end = 'completed C:\\symscripts\\1_4_1_Transfer.bat PDBSTGACACON01'
sta_system = 'ST1'
sta_schema = 'PDBSTGACACON01'
sta_seq_b = 'SEQ_STAB.NEXTVAL'
sta_seq_c = 'SEQ_STAC.NEXTVAL'
sta_seq_r = 'SEQ_STAR.NEXTVAL'

def stb():
    print("Schema ST2")
stb_file_name = '{}_expdp_PDBLCBE_ADMIN.log'.format(timestampStr3)
stb_file_name_restore = '{}_impdp_PDBLCBE_ADMIN.log'.format(timestampStr3)
stb_value ='{}{}'.format(path_name,stb_file_name)
stb_value_restore ='{}{}'.format(path_name_restore,stb_file_name_restore)
stb_value_start = 'start data transfer C:\\symscripts\\1_4_1_Transfer.bat PDBLCBE_ADMIN'
stb_value_end = 'completed C:\\symscripts\\1_4_1_Transfer.bat PDBLCBE_ADMIN'
stb_system = 'ST2'
stb_schema = 'PDBLCBE_ADMIN'
stb_seq_b = 'SEQ_STBB.NEXTVAL'
stb_seq_c = 'SEQ_STBC.NEXTVAL'
stb_seq_r = 'SEQ_STBR.NEXTVAL'


def stc():
    print("Schema ST3")
stc_file_name = '{}_expdp_OLSS_MFAPPL.log'.format(timestampStr3)
stc_file_name_restore = '{}_impdp_OLSS_MFAPPL.log'.format(timestampStr3)
stc_value='{}{}'.format(path_name,stc_file_name)
stc_value_restore ='{}{}'.format(path_name_restore,stc_file_name_restore)
stc_value_start = 'start data transfer C:\\symscripts\\1_4_1_Transfer.bat OLSS_MFAPPL'
stc_value_end = 'completed C:\\symscripts\\1_4_1_Transfer.bat OLSS_MFAPPL'
stc_system = 'ST3'
stc_schema = 'OLSS_MFAPPL'
stc_seq_b = 'SEQ_STCB.NEXTVAL'
stc_seq_c = 'SEQ_STCC.NEXTVAL'
stc_seq_r = 'SEQ_STCR.NEXTVAL'

start_date = datetime(2019,2,1)
end_date = datetime(2019,9,22)