# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 16:33:45 2019

@author: Muhammad Sopyan
"""
import modul_define
import pathlib
import cx_Oracle
import re
import os
from datetime import datetime,timedelta
os.chdir('{}'.format(modul_define.client))

def walk_days(start_date, end_date):
    if start_date <= end_date:
        timestampStr1 = start_date.strftime("%b %d %Y %H:%M:%S")
        timestampStr2 = start_date.strftime("%b %d %Y")
        timestampStr3 = start_date.strftime("%Y%m%d")
        file_name = '{}_impdp_PDBLCBE_ADMIN.log'.format(timestampStr3)
        path_name = '{}'.format(modul_define.path_name_restore)
        value='{}{}'.format(path_name,file_name)
        print(r'Path File         :' ,value)
        
        #---file name exists or doesn't exisist---
        file = pathlib.Path("{}".format(value))
        if file.exists ():
            #reading file
            with open('{}'.format(value), 'r') as f:
               data = f.readlines()
               #print(data)
            
            #parsing Start Time
            index = 0
            string_start = re.search('Import: ', str(data))
            objstring_start = '{}'.format(string_start)
            #print(objstring_start)
        
            if objstring_start =='None':
                start_time = ''
                print(r'Start Time        :' ,start_time)
            else:
                objstring_start1 = '{}'.format(string_start.group())
                for baris in data:
                    index+=1
                    if objstring_start1 in baris:
                        break
                for x, lines in enumerate(data):
                    if x == index-1 :
                        objstar_time = re.search('(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s\d+\s',str(lines))
                        objstar_time1 = re.search('\s(20)\d{2}',str(lines))
                        tahun= '{}'.format(objstar_time1.group())
                        start_time = lines.split('{}'.format(objstar_time.group()))[1].split('{}'.format(tahun))[0]
                        print(r'Start Time        :' ,start_time)
        
            #parsing Status
            index1 = 0
            string_status = re.search('completed with|Failed', str(data))
            objstring_status = '{}'.format(string_status)
            #print(objstring_status)   
            if objstring_status =='None':
                status=''
                print(r'Status            :' ,status)
            else:
                objstring_status1 = '{}'.format(string_status.group())
                for baris1 in data:
                    index1+=1
                    if objstring_status1 in baris1:
                        break
                for x1, lines1 in enumerate(data):
                    if x1 == index1-1 :
                        status = lines.split('SYS\_IMPORT\_FULL\_[0-9][0-9]\" ')[0].split(' at')[0]
                        print(r'Status            :' ,status)   
             
            #parsing end_time
            index3 = 0
            stringend_time = re.search('Job', str(data))
            objstringend_time = '{}'.format(stringend_time)
            #print(stringend_time)
            if objstringend_time =='None':
                end_time=''
                print(r'End Time          :' ,end_time)
            else:
                objstringend_time1 = '{}'.format(stringend_time.group())
                for baris3 in data:
                    index3+=1
                    if objstringend_time1 in baris3:
                        break
            for x3, lines3 in enumerate(data):
                if x3 == index3-1 :
                    objend_time = re.search('\d{2}\:\d{2}\:\d{2}',str(lines3))
                    end_time = '{}'.format(objend_time.group())
                    print(r'End Time          :' ,end_time)
            
            #file_name
            index4 = 0
            string_file_name = re.search('Starting', str(data))
            objstring_file_name = '{}'.format(string_file_name)
            #print(objstring_file_name)
            if objstring_file_name =='None':
                file_name = ''
                print(r'File Name         :',file_name)
            else:
                objstring_file_name1 = '{}'.format(string_file_name.group())
                for baris4 in data:
                    index4+=1
                    if objstring_file_name1 in baris4:
                       break
                for x4, lines4 in enumerate(data):
                    if x4 == index4-1 :
                        file_name = lines4.split(' system/********@STG01P directory=dbdumps ')[1].split(' ' )[0]
                        print(r'File Name         :',file_name)
        
            f.close()
            
            #insert into table oracle
            if objstring_start=='None' or objstring_status=='None' or objstringend_time=='None' or objstring_file_name=='None':
                try: 
                    con = cx_Oracle.connect('{}'.format(modul_define.connector))    
                    cur = con.cursor()
                    sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{}\',\'{}\',\'{}\',\'\',\'{}\',\'\',\'Process Not Completed\')'.format(modul_define.user,modul_define.stb_system,modul_define.restore,modul_define.stb_seq_r,modul_define.stb_schema,timestampStr1,status,end_time,file_name)
                    cur.execute(sql_command)          
                    con.commit()       
                    print("value inserted  : Process Not Completed") 
            
                except cx_Oracle.DatabaseError as e: 
                    print("There is a problem with Oracle", e) 
                finally: 
                    if cur: 
                        cur.close() 
                    if con: 
                        con.close()
            else:
                try: 
                    con = cx_Oracle.connect('{}'.format(modul_define.connector))    
                    cur = con.cursor()
                    sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{} {}\',\'{}\',\'{} {}\',\'\',\'{}\',\'\',\'Process Completed\')'.format(modul_define.user,modul_define.stb_system,modul_define.restore,modul_define.stb_seq_r,modul_define.stb_schema,timestampStr2,start_time,status,timestampStr2,end_time,file_name)
                    cur.execute(sql_command)          
                    con.commit()       
                    print("value inserted    : Successful") 
            
                except cx_Oracle.DatabaseError as e: 
                    print("There is a problem with Oracle", e) 
                finally: 
                    if cur: 
                        cur.close() 
                    if con: 
                        con.close()
            
        
        else:
            print("File not exist")
            
            try: 
                con = cx_Oracle.connect('{}'.format(modul_define.connector))
                cur = con.cursor()
                sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{}\',\'FAILED\',\'\',\'\',\'\',\'\',\'File not found\')'.format(modul_define.user,modul_define.stb_system,modul_define.restore,modul_define.stb_seq_r,modul_define.stb_schema,timestampStr1)
                cur.execute(sql_command)                          
                con.commit()       
                print("value inserted    : File Not Exists") 
               
            except cx_Oracle.DatabaseError as e: 
                print("There is a problem with Oracle", e) 
            
            finally: 
                if cur: 
                    cur.close() 
                if con: 
                    con.close()
                    
        next_date = start_date + timedelta(days=1)
        walk_days(next_date, end_date)
        
start_date = datetime(2019,4,1)
end_date = datetime(2019,9,24)
walk_days(start_date, end_date)