# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 10:16:07 2019

@author: Muhammad Tedi Sopyan
"""
import modul_define
import pathlib
import cx_Oracle
import re
import os
from datetime import datetime,timedelta
os.chdir('{}'.format(modul_define.client))

def walk_days(start_date, end_date):
    if start_date <= end_date:
        timestampStr1 = start_date.strftime("%b %d %Y %H:%M:%S")
        timestampStr2 = start_date.strftime("%b %d %Y")
        timestampStr3 = start_date.strftime("%Y%m%d")
        file_name = '{}_backup.log'.format(timestampStr3)
        path_name = '{}'.format(modul_define.path_name)
        value='{}{}'.format(path_name,file_name)
        print(r'Path File      :' ,value)
        
        #---file name exists or doesn't exisist---
        file = pathlib.Path('{}'.format(value))
        if file.exists ():
            #reading file
            with open('{}'.format(value), 'r') as f:
               data = f.readlines()
            
            start_string = '{}'.format(modul_define.stb_value_start)
            end_string = '{}'.format(modul_define.stb_value_end)
            flag=index = 0
            for baris in data:
                index+=1
                if start_string in baris:
                    flag=1
                    break
        
            flag1=index1 = 0
            for baris1 in data:
                index1+=1
                if '{}'.format(end_string) in baris1:
                    flag1=1
                    break
            
            if flag==0 or flag1==0:
                f.close()
                print('No data found in current file')
                
                try:
                    con = cx_Oracle.connect('{}'.format(modul_define.connector))    
                    cur = con.cursor()
                    sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{}\',\'FAILED\',\'\',\'\',\'\',\'\',\'File not found\')'.format(modul_define.user,modul_define.stb_system, modul_define.copy, modul_define.stb_seq_c, modul_define.stb_schema, timestampStr1)
                    cur.execute(sql_command)                          
                    con.commit()
                    print("Value inserted : File Not Exist") 
        
                except cx_Oracle.DatabaseError as e: 
                    print("There is a problem with Oracle", e) 
                
                finally: 
                    if cur: 
                        cur.close() 
                    if con: 
                        con.close()
                
            else:
                with open('{}'.format(value), 'r') as fh:
                    data1 = fh.readlines()[index-1:index1]
                
                #Parsing Start Time
                stringToMatch = 'Started : '
                matchedLine = ''
                for line in data1:
                	if stringToMatch in line:
                		matchedLine = line
                		break
                objstar_time = re.search('\d\:\d{2}\:\d{2}|\d{2}\:\d{2}\:\d{2}',str(matchedLine))
                if objstar_time =='None':
                    print(r'Before Started :',objstar_time)
                else:
                    print(r'Before Started :',objstar_time.group())
                replace = re.search('(12)\:\d{2}\:\d{2}',str(matchedLine))
                find='{}'.format(replace)
                if find=='None':
                    print('Current Time Parsing')
                    value0 ='{}'.format(objstar_time.group())
                    start_time = '{}'.format(value0)
                    print('After Started  : {}'.format(start_time))
                else:
                    print('Replace Start Time')
                    start_time = '{}'.format(replace.group())
                    l0 = list(start_time)
                    l0[0] = '0'
                    l0[1] = '0'
                    start_time = ''.join(l0)
                    print('After Started  : {}'.format(start_time))
                
                #Parsing Ukuran
                stringToMatch1 = 'Bytes : '
                matchedLine1 = ''
                for line1 in data1:
                	if stringToMatch1 in line1:
                		matchedLine1 = line1
                		break
            
                x1 = re.search('[0-9]\.[0-9][0-9][0-9]\sg|[0-9][0-9][0-9]\.[0-9][0-9]\sm', matchedLine1)
                ukuran=(x1.group())
                print('Bytes          : {}'.format(ukuran))
                
                #Parsing Elapsed Time
                stringToMatch2 = 'Times :   '
                matchedLine2 = ''
                for line2 in data1:
                	if stringToMatch2 in line2:
                		matchedLine2 = line2
                		break
                search_times = matchedLine2.split('Times :   ')[1].split(' ')[0]
                print('Times          : {}'.format(search_times))
                
                #Parsing End Time
                stringToMatch3 = 'Ended : '
                matchedLine3 = ''
                for line3 in data1:
                	if stringToMatch3 in line3:
                		matchedLine3 = line3
                		break
                objend_time = re.search('\d\:\d{2}\:\d{2}|\d{2}\:\d{2}\:\d{2}',str(matchedLine3))
                if objend_time =='None':
                    print(r'Before Ended   :',objend_time)
                else:
                    print(r'Before Ended   :',objend_time.group())
                replace1 = re.search('(12)\:\d{2}\:\d{2}',str(matchedLine3))
                find1 ='{}'.format(replace1)
                if find1 =='None':
                    print('Current Time Parsing')
                    value1 ='{}'.format(objend_time.group())
                    end_time = '{}'.format(value1)
                    print('After Ended    : {}'.format(end_time))
                else:
                    print('Replace End Time')
                    end_time = '{}'.format(replace1.group())
                    l1 = list(end_time)
                    l1[0] = '0'
                    l1[1] = '0'
                    end_time = ''.join(l1)
                    print('After Ended    : {}'.format(end_time))
                
                #Parsing File name
                stringToMatch4 = 'Files : '
                matchedLine4 = ''
                for line4 in data1:
                	if stringToMatch4 in line4:
                		matchedLine4 = line4
                		break
                file_name = matchedLine4.split('Files : ')[1]
                print('File Name      : {}'.format(file_name))
                
                #Parsing Status
                stringToMatch5 = 'completed'
                matchedLine5 = ''
                for line5 in data1:
                	if stringToMatch5 in line5:
                		matchedLine5 = line5
                		break
                #print(matchedLine5)
                status = matchedLine5.split('-------------------- ')[1].split(' ')[0]
                print('Status         : {}'.format(status))
                
                f.close()
                fh.close()
                #insert into table oracle
                
                try: 
                    con = cx_Oracle.connect('{}'.format(modul_define.connector))
                    cur = con.cursor()
                    sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{} {}\',\'{}\',\'{} {}\',\'{}\',\'{}\',\'{}\',\'Process Completed\')'.format(modul_define.user,modul_define.stb_system, modul_define.copy, modul_define.stb_seq_c, modul_define.stb_schema, timestampStr2, start_time,status, timestampStr2, end_time, search_times, file_name, ukuran)
                    cur.execute(sql_command)          
                    con.commit()       
                    print("Value inserted : successful") 
            
                except cx_Oracle.DatabaseError as e: 
                    print("There is a problem with Oracle", e) 
            
                finally: 
                    if cur: 
                        cur.close() 
                    if con: 
                        con.close()
                
                
        else:
            print("File not exist")
            
            try:
                con = cx_Oracle.connect('{}'.format(modul_define.connector))    
                cur = con.cursor()
                sql_command = 'insert into {}.Monitoring VALUES(\'{}\',\'{}\',{},\'{}\',\'{}\',\'FAILED\',\'\',\'\',\'\',\'\',\'File not found\')'.format(modul_define.user,modul_define.stb_system, modul_define.copy, modul_define.stb_seq_c, modul_define.stb_schema, timestampStr1)
                cur.execute(sql_command)                          
                con.commit()
                print("Value inserted : File Not Exist") 
        
            except cx_Oracle.DatabaseError as e: 
                print("There is a problem with Oracle", e) 
            
            finally: 
                if cur: 
                    cur.close() 
                if con: 
                    con.close()
            
        next_date = start_date + timedelta(days=1)
        walk_days(next_date, end_date)
        
start_date = datetime(2019,4,1)
end_date = datetime(2019,9,24)
walk_days(start_date, end_date)