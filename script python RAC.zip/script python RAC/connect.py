# -*- coding: utf-8 -*-
"""
Created on Tue Aug 13 11:30:49 2019

@author: MuhammadSoSis
"""

import os
os.chdir("C:\\instantclient_19_3")
import cx_Oracle
# con = cx_Oracle.connect('username/password@[ipaddress]/SID')
con = cx_Oracle.connect('monitor/monitor@172.17.30.77/XE')
print ("Connected To " + con.version)

cur = con.cursor()
sql='select name from v$database'
cur.execute(sql)
for result in cur:
    print (result)

f=open('D:\\DR-MONITORING\\SII-DR-Monitoring-master\\test_connect.log','a')
f.write(sql+'\n')

if cur:
   cur.close()
if con:
   con.close()